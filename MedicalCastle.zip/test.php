<?php
/* session_start();
if(!isset($_SESSION['username'])){
   header('location: dashboard.php');
   exit();
} */
  $noNav = "no";
  $noSideBar = "no";
   include "init.php"; 
   ?>
    <main class="m-5 p-5">
         
      
    <br>
    <br>
   <?php
      foreach($municipalsArray as $municipal){
         echo "<option value='". $municipal. "'>". langTown($municipal). "</option>";
      }

  echo "</main>";
   include $tempsP. "footer.php";
   