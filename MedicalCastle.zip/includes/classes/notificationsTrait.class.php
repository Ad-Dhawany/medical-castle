<?php
trait notificationsTrait{

/**********************************/
}