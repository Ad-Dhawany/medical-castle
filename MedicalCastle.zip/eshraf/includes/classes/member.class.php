<?php /* require_once('../../confiq.php'); */
class member extends subscriber{
    
     /* */
     function setGroupID($groupID){
        $this->groupID = $groupID;
    }
    /****************************/
}